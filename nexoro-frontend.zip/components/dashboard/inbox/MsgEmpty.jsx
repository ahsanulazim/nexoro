const MsgEmpty = () => {
    return (
        <li className="">
            <p className="text-center w-full py-10 opacity-60">No messages to display.</p>
        </li>
    )
}

export default MsgEmpty
