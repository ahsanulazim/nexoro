import Marquee from "react-fast-marquee";
import images from "@/json/marqueeImage.json";
import Image from "next/image";

export default function CardsMarquee({ direction, className }) {
  return (
    <Marquee
      speed={30}
      autoFill={true}
      className={`absolute! rotate-80 overflow-x-visible! -z-10 ${className ? className : ""}`}
      direction={direction ? direction : "left"}
    >
      {images.map((image) => (
        <Image
          height={800}
          width={450}
          key={image.id}
          src={image.image}
          alt={image.title}
          className="max-w-56 mx-3 rounded-xl"
        />
      ))}
    </Marquee>
  );
}
