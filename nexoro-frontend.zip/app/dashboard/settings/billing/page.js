const billing = () => {
  return <div>billing</div>;
};

export default billing;
