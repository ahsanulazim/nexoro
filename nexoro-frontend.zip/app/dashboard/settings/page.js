const page = () => {
  return <section>settings</section>;
};

export default page;
