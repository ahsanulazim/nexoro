const page = () => {
  return <div>refferals</div>;
};

export default page;
