import DashboardUi from "@/components/dashboard/DashboardUi";

export default function page() {
    return (
        <DashboardUi />
    )
}
