import Header from "@/components/Header";

export default function layout({ children }) {
    return (
        <Header>{children}</Header>
    )
}
