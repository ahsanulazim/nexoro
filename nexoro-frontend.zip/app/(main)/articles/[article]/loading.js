import Loader from "@/components/ui/Loader";

const loading = () => {
  return <Loader />;
};

export default loading;
