import CompanyDetails from "@/components/about/CompanyDetails";
import PartnerShip from "@/components/about/PartnerShip";
import TitleBanner from "@/components/ui/TitleBanner";

const About = () => {
  return (
    <main>
      <TitleBanner>About Us</TitleBanner>
      <CompanyDetails />
      <PartnerShip />
    </main>
  );
};

export default About;
