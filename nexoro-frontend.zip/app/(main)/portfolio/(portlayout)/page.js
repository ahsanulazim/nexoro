import AllPortfolios from "@/components/portfolio/AllPortfolios"

const page = () => {
    return (
        <>
            <AllPortfolios />
        </>
    )
}

export default page