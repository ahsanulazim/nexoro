import { notFound } from "next/navigation"

const page = () => {
    return notFound();
}

export default page