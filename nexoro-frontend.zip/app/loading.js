const loading = () => {
    return (
        <div className="text-center py-10">loading...</div>
    )
}

export default loading